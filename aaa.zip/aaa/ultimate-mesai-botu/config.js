// config.js
module.exports = {
    department: {
        name: "Blaine County Sheriff Department", // Burası güncellendi
        logoUrl: "https://example.com/blaine-sheriff-logo.png", // Buraya Blaine County Sheriff Departmanı logosunun URL'sini ekleyebilirsiniz
        theme: {
            primary: "#4CAF50", // Örnek olarak Sheriff temasına uygun yeşil tonları
            secondary: "#FFC107" // Örnek olarak sarı/turuncu tonları
        }
    },
    ranks: [
        { id: "rank_id_cadet", name: "Cadet", roleId: "DISCORD_ROLE_ID_CADET" },
        { id: "rank_id_deputy", name: "Deputy", roleId: "DISCORD_ROLE_ID_DEPUTY" },
        { id: "rank_id_sergeant", name: "Sergeant", roleId: "DISCORD_ROLE_ID_SERGEANT" },
        { id: "rank_id_lieutenant", name: "Lieutenant", roleId: "DISCORD_ROLE_ID_LIEUTENANT" },
        { id: "rank_id_captain", name: "Captain", roleId: "DISCORD_ROLE_ID_CAPTAIN" },
        { id: "rank_id_major", name: "Major", roleId: "DISCORD_ROLE_ID_MAJOR" },
        { id: "rank_id_high_command", name: "High Command", roleId: "DISCORD_ROLE_ID_HIGH_COMMAND" } // High Command rolü
    ],
    // Mesai ayarları
    mesai: {
        maxHoursBeforeForceKick: 5, // Otomatik atılmadan önceki maksimum mesai süresi (saat)
        reminderIntervalMinutes: 60 // Mesai hatırlatma aralığı (dakika)
    },
    // Web sitesi ayarları (daha sonra kullanılacak)
    web: {
        domain: "localhost:3000",
        highCommandRoleId: "DISCORD_ROLE_ID_HIGH_COMMAND" // Web sitesi erişimi için High Command rolü
    }
};