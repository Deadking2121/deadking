// src/core/utils.js
module.exports = {
    formatDuration: (ms) => {
        const seconds = Math.floor((ms / 1000) % 60);
        const minutes = Math.floor((ms / (1000 * 60)) % 60);
        const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
        const days = Math.floor(ms / (1000 * 60 * 60 * 24));

        let parts = [];
        if (days > 0) parts.push(`${days} gün`);
        if (hours > 0) parts.push(`${hours} saat`);
        if (minutes > 0) parts.push(`${minutes} dakika`);
        if (seconds > 0 && parts.length < 2) parts.push(`${seconds} saniye`); // Saniyeyi sadece daha kısa süreler için göster

        return parts.length > 0 ? parts.join(' ') : '0 saniye';
    },
    // Diğer yardımcı fonksiyonlar buraya eklenebilir
};