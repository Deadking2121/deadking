// src/core/logger.js
const winston = require('winston');
const dotenv = require('dotenv');

dotenv.config(); // .env dosyasını burada da yükleyelim

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.colorize(),
        winston.format.printf(info => `${info.timestamp} ${info.level}: ${info.message}`)
    ),
    transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
        new winston.transports.File({ filename: 'logs/combined.log' })
    ]
});

// Discord'a log gönderme fonksiyonu (botun ana dosyasında kullanılacak)
logger.discordLog = (message, level = 'info') => {
    // Bu fonksiyonu botun `client` objesi üzerinden kullanacağız.
    // Gerçek gönderim `src/bot/index.js` içinde `client.channels.cache.get(process.env.LOG_CHANNEL_ID).send()` ile yapılacak.
};

module.exports = logger;