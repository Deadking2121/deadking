// src/bot/index.js
const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const { CronJob } = require('cron'); // Mesai hatırlatma ve otomatik çıkış için
const logger = require('../core/logger');
const config = require('../../config');
const User = require('../database/models/User');
const Log = require('../database/models/Log');
const { formatDuration } = require('../core/utils');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages // DM göndermek için
    ],
});

client.commands = new Collection(); // Slash komutlarını depolamak için
client.cooldowns = new Collection(); // Komut bekleme süreleri için

// Komutları yükleme fonksiyonu
const loadCommands = () => {
    const fs = require('node:fs');
    const path = require('node:path');
    const commandsPath = path.join(__dirname, '../commands');
    const commandFolders = fs.readdirSync(commandsPath);

    for (const folder of commandFolders) {
        const folderPath = path.join(commandsPath, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        for (const file of commandFiles) {
            const filePath = path.join(folderPath, file);
            const command = require(filePath);
            if ('data' in command && 'execute' in command) {
                client.commands.set(command.data.name, command);
                logger.info(`Komut yüklendi: /${command.data.name}`);
            } else {
                logger.warn(`[UYARI] ${filePath} adresindeki komutun "data" veya "execute" özelliği eksik.`);
            }
        }
    }
};

// Olayları yükleme fonksiyonu
const loadEvents = () => {
    const fs = require('node:fs');
    const path = require('node:path');
    const eventsPath = path.join(__dirname, '../events');
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
    }
};

// Slash komutlarını Discord API'ye kaydetme
const registerSlashCommands = async () => {
    const commands = [];
    client.commands.forEach(command => commands.push(command.data.toJSON()));

    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_BOT_TOKEN);

    try {
        logger.info(`Toplam ${commands.length} slash komutu yenileniyor.`);

        // Geliştirme aşamasında belirli bir sunucuya kaydetmek daha hızlıdır
        const data = await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
            { body: commands },
        );
        logger.info(`${data.length} slash komutu başarıyla kaydedildi.`);
    } catch (error) {
        logger.error('Slash komutları kaydedilirken hata oluştu:', error);
    }
};

// Mesai Kontrol ve Hatırlatma İşlemleri
const setupMesaiAutomation = () => {
    // Her saat başı mesai kontrolü ve hatırlatma
    new CronJob('0 * * * *', async () => { // Her saat 0. dakikada çalışır
        logger.info('Mesai kontrol ve hatırlatma cron job çalışıyor...');
        const activeUsers = await User.find({ "timesheets.endTime": null });

        for (const userDoc of activeUsers) {
            const lastEntry = userDoc.timesheets[userDoc.timesheets.length - 1];
            if (!lastEntry || lastEntry.endTime) continue; // Zaten çıkış yapmışsa veya kayıt yoksa atla

            const durationMs = new Date().getTime() - lastEntry.startTime.getTime();
            const durationHours = durationMs / (1000 * 60 * 60);

            // 5 saatten fazla mesai yapanları mesaiden çıkartma
            if (durationHours >= config.mesai.maxHoursBeforeForceKick) {
                lastEntry.endTime = new Date();
                lastEntry.duration = lastEntry.endTime.getTime() - lastEntry.startTime.getTime();
                await userDoc.save();

                const discordUser = await client.users.fetch(userDoc.discordId).catch(() => null);
                if (discordUser) {
                    const totalDuration = formatDuration(lastEntry.duration);
                    discordUser.send(
                        `**OTOMATİK MESAİ ÇIKIŞI:** ${totalDuration} süredir mesaide olduğunuz için sistem tarafından mesaiden çıkarıldınız. Lütfen dikkatli olunuz.`
                    ).catch(err => logger.error(`DM gönderilirken hata: ${err.message}`));
                    logger.info(`${userDoc.username} (${userDoc.discordId}) otomatik olarak mesaiden çıkarıldı.`);

                    // Log kanalına bildirim
                    const logChannel = client.channels.cache.get(process.env.LOG_CHANNEL_ID);
                    if (logChannel) {
                        logChannel.send(`🚨 **Otomatik Mesai Çıkışı:** <@${userDoc.discordId}>, ${totalDuration} süredir mesaide olduğu için sistem tarafından mesaiden çıkarıldı.`);
                    }

                    // Log kaydı
                    await Log.create({
                        type: 'OTOMATIK_CIKIS',
                        userId: userDoc.discordId,
                        username: userDoc.username,
                        guildId: userDoc.guildId,
                        details: `Otomatik olarak mesaiden çıkarıldı. Süre: ${totalDuration}`
                    });
                }
            }
            // Mesai hatırlatma (örn: her saat başı)
            else if (durationHours >= 1 && durationHours % (config.mesai.reminderIntervalMinutes / 60) === 0) {
                const discordUser = await client.users.fetch(userDoc.discordId).catch(() => null);
                if (discordUser) {
                    const currentDuration = formatDuration(durationMs);
                    discordUser.send(
                        `**MESAİ HATIRLATMA:** ${currentDuration} süredir mesaide görünüyorsunuz. Mesainizi bitirmeyi unutmayın!`
                    ).catch(err => logger.error(`DM gönderilirken hata: ${err.message}`));
                    logger.info(`${userDoc.username} (${userDoc.discordId}) mesai hatırlatması aldı.`);
                }
            }
        }
    }, null, true, 'Europe/Istanbul'); // 'Europe/Istanbul' zaman dilimine göre çalışır
    logger.info('Mesai otomasyon cron job başlatıldı.');
};


module.exports = {
    start: () => {
        if (!process.env.DISCORD_BOT_TOKEN) {
            logger.error('DISCORD_BOT_TOKEN .env dosyasında tanımlı değil!');
            return;
        }
        if (!process.env.CLIENT_ID) {
            logger.error('CLIENT_ID .env dosyasında tanımlı değil!');
            return;
        }
        if (!process.env.GUILD_ID) {
            logger.warn('GUILD_ID .env dosyasında tanımlı değil. Slash komutları global olarak kaydedilebilir, ancak geliştirme için önerilir.');
        }

        loadCommands(); // Komutları yükle
        loadEvents();   // Olayları yükle

        client.login(process.env.DISCORD_BOT_TOKEN).then(() => {
            registerSlashCommands(); // Bot giriş yaptıktan sonra slash komutlarını kaydet
            setupMesaiAutomation(); // Otomasyonu başlat
        }).catch(err => {
            logger.error('Discord botuna giriş yapılırken hata oluştu:', err);
        });
    },
    getClient: () => client // Dışarıdan client objesine erişim için
};