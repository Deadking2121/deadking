// src/events/interactionCreate.js
const logger = require('../../src/core/logger');
const { Collection } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);

            if (!command) {
                logger.error(`Geçersiz komut: ${interaction.commandName}`);
                return;
            }

            try {
                await command.execute(interaction, client);
            } catch (error) {
                logger.error(`Komut çalıştırılırken hata oluştu: ${interaction.commandName}`, error);
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ content: 'Bu komutu çalıştırırken bir hata oluştu!', ephemeral: true });
                } else {
                    await interaction.reply({ content: 'Bu komutu çalıştırırken bir hata oluştu!', ephemeral: true });
                }
            }
        } else if (interaction.isButton()) {
            const [customIdPrefix, action] = interaction.customId.split('_');

            if (customIdPrefix === 'mesai') {
                if (action === 'giris' || action === 'cikis') {
                    const command = client.commands.get(action);
                    if (command) {
                        try {
                            // Buton etkileşimini komut gibi çalıştır
                            await command.execute(interaction, client);
                            // Mesai menüsünü otomatik olarak yenile
                            await client.commands.get('mesaimenu').execute(interaction, client);
                        } catch (error) {
                            logger.error(`Mesai butonu çalıştırılırken hata oluştu: ${interaction.customId}`, error);
                            if (interaction.replied || interaction.deferred) {
                                await interaction.followUp({ content: 'Bu işlemi yaparken bir hata oluştu!', ephemeral: true });
                            } else {
                                await interaction.reply({ content: 'Bu işlemi yaparken bir hata oluştu!', ephemeral: true });
                            }
                        }
                    }
                } else if (action === 'yenile') {
                    // Mesai menüsü yenileme komutunu çağır
                    const mesaiMenuCommand = client.commands.get('mesaimenu');
                    if (mesaiMenuCommand) {
                        try {
                            await mesaiMenuCommand.execute(interaction, client);
                        } catch (error) {
                            logger.error(`Mesai menüsü yenilenirken hata oluştu:`, error);
                            if (interaction.replied || interaction.deferred) {
                                await interaction.followUp({ content: 'Menü yenilenirken bir hata oluştu!', ephemeral: true });
                            } else {
                                await interaction.reply({ content: 'Menü yenilenirken bir hata oluştu!', ephemeral: true });
                            }
                        }
                    }
                }
            }
        }
    },
};