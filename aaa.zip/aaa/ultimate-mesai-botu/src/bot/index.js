// src/bot/index.js
const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const { CronJob } = require('cron');
const logger = require('../core/logger');
const config = require('../../config');
const { formatDuration } = require('../core/utils');

// Quick.db için bir veritabanı örneği oluşturalım
const { QuickDB } = require("quick.db");
const db = new QuickDB({ filePath: "./data/bot_data.sqlite" }); // Veriler data/bot_data.sqlite dosyasında tutulacak

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ],
});

client.commands = new Collection();
client.cooldowns = new Collection();
client.db = db; // Komut dosyalarından erişim için db nesnesini client'a ekle

// Komutları yükleme fonksiyonu
const loadCommands = () => {
    const fs = require('node:fs');
    const path = require('node:path');
    const commandsPath = path.join(__dirname, '../commands');
    const commandFolders = fs.readdirSync(commandsPath);

    for (const folder of commandFolders) {
        const folderPath = path.join(commandsPath, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        for (const file of commandFiles) {
            const filePath = path.join(folderPath, file);
            const command = require(filePath);
            if ('data' in command && 'execute' in command) {
                client.commands.set(command.data.name, command);
                logger.info(`Komut yüklendi: /${command.data.name}`);
            } else {
                logger.warn(`[UYARI] ${filePath} adresindeki komutun "data" veya "execute" özelliği eksik.`);
            }
        }
    }
};

// Olayları yükleme fonksiyonu
const loadEvents = () => {
    const fs = require('node:fs');
    const path = require('node:path');
    const eventsPath = path.join(__dirname, '../events');
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
    }
};

// Slash komutlarını Discord API'ye kaydetme
const registerSlashCommands = async () => {
    const commands = [];
    client.commands.forEach(command => commands.push(command.data.toJSON()));

    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_BOT_TOKEN);

    try {
        logger.info(`Toplam ${commands.length} slash komutu yenileniyor.`);

        const data = await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
            { body: commands },
        );
        logger.info(`${data.length} slash komutu başarıyla kaydedildi.`);
    } catch (error) {
        logger.error('Slash komutları kaydedilirken hata oluştu:', error);
    }
};

// Kullanıcı verilerini Quick.db'den getiren/oluşturan yardımcı fonksiyon
// Quick.db'de kullanıcı verilerini "users.<discordId>" şeklinde tutacağız
async function getUserData(userId, guildId, username) {
    let userData = await db.get(`users.${userId}`);
    if (!userData) {
        userData = {
            discordId: userId,
            username: username,
            guildId: guildId,
            rank: 'Üye', // Varsayılan rütbe
            timesheets: [],
            createdAt: Date.now(),
            lastActivity: Date.now()
        };
        await db.set(`users.${userId}`, userData);
    }
    // Kullanıcı adı değişmişse güncelleyelim
    if (userData.username !== username) {
        userData.username = username;
        await db.set(`users.${userId}`, userData);
    }
    return userData;
}

// Log verilerini Quick.db'ye kaydeden yardımcı fonksiyon
// Quick.db'de logları "logs" dizisine ekleyeceğiz
async function addLogEntry(type, userId, username, guildId, details, performerId = null, performerUsername = null) {
    const logEntry = {
        type,
        userId,
        username,
        guildId,
        details,
        timestamp: Date.now(),
        performerId,
        performerUsername
    };
    await db.push('logs', logEntry); // logs dizisine yeni log ekle
}


// Mesai Kontrol ve Hatırlatma İşlemleri
const setupMesaiAutomation = () => {
    // Her saat başı mesai kontrolü ve hatırlatma
    new CronJob('0 * * * *', async () => { // Her saat 0. dakikada çalışır
        logger.info('Mesai kontrol ve hatırlatma cron job çalışıyor...');
        const allUsersData = await db.get('users') || {}; // db nesnesi zaten yukarıda tanımlı

        for (const userId in allUsersData) {
            const userDoc = allUsersData[userId];

            // 1. userDoc'un geçerli bir obje olduğundan emin ol
            if (typeof userDoc !== 'object' || userDoc === null) {
                logger.warn(`Quick.db'den geçersiz kullanıcı verisi bulundu (ID: ${userId}). Atlanıyor.`);
                continue; // Geçersizse bu girişi atla
            }

            // 2. timesheets özelliğinin bir dizi olduğundan ve boş olmadığından emin ol
            // Array.isArray() undefined veya null için false döner, bu yüzden güvenlidir.
            if (!Array.isArray(userDoc.timesheets) || userDoc.timesheets.length === 0) {
                // logger.info(`Kullanıcı ${userDoc.username || userId} aktif mesaide değil veya mesai kaydı yok. Atlanıyor.`); // Debug için bu satırı açabilirsiniz
                continue; // Eğer mesai kaydı yoksa veya geçersizse atla
            }

            const lastEntry = userDoc.timesheets[userDoc.timesheets.length - 1];
            if (lastEntry.endTime) continue; // Zaten çıkış yapmışsa atla

            const durationMs = Date.now() - lastEntry.startTime; // startTime doğrudan milisaniye olarak tutulduğu varsayılıyor
            const durationHours = durationMs / (1000 * 60 * 60);

            // 5 saatten fazla mesai yapanları mesaiden çıkartma
            if (durationHours >= config.mesai.maxHoursBeforeForceKick) {
                lastEntry.endTime = Date.now();
                lastEntry.duration = lastEntry.endTime - lastEntry.startTime;

                // Dizideki kaydı doğrudan güncelle
                userDoc.timesheets[userDoc.timesheets.length - 1] = lastEntry;
                await db.set(`users.${userId}`, userDoc); // Kullanıcı verisini güncelle

                const discordUser = await client.users.fetch(userDoc.discordId).catch(() => null);
                if (discordUser) {
                    const totalDuration = formatDuration(lastEntry.duration);
                    discordUser.send(
                        `**OTOMATİK MESAİ ÇIKIŞI:** ${totalDuration} süredir mesaide olduğunuz için sistem tarafından mesaiden çıkarıldınız. Lütfen dikkatli olunuz.`
                    ).catch(err => logger.error(`DM gönderilirken hata: ${err.message}`));
                    logger.info(`${userDoc.username} (${userDoc.discordId}) otomatik olarak mesaiden çıkarıldı.`);

                    const logChannel = client.channels.cache.get(process.env.LOG_CHANNEL_ID);
                    if (logChannel) {
                        logChannel.send(`🚨 **Otomatik Mesai Çıkışı:** <@${userDoc.discordId}>, ${totalDuration} süredir mesaide olduğu için sistem tarafından mesaiden çıkarıldı.`);
                    }

                    await addLogEntry(
                        'OTOMATIK_CIKIS',
                        userDoc.discordId,
                        userDoc.username,
                        userDoc.guildId,
                        `Otomatik olarak mesaiden çıkarıldı. Süre: ${totalDuration}`
                    );
                }
            }
            // Mesai hatırlatma (örn: her saat başı)
            else if (durationHours >= 1 && durationHours % (config.mesai.reminderIntervalMinutes / 60) === 0) {
                const discordUser = await client.users.fetch(userDoc.discordId).catch(() => null);
                if (discordUser) {
                    const currentDuration = formatDuration(durationMs);
                    discordUser.send(
                        `**MESAİ HATIRLATMA:** ${currentDuration} süredir mesaide görünüyorsunuz. Mesainizi bitirmeyi unutmayın!`
                    ).catch(err => logger.error(`DM gönderilirken hata: ${err.message}`));
                    logger.info(`${userDoc.username} (${userDoc.discordId}) mesai hatırlatması aldı.`);
                }
            }
        }
    }, null, true, 'Europe/Istanbul');
    logger.info('Mesai otomasyon cron job başlatıldı.');
};


module.exports = {
    start: () => {
        if (!process.env.DISCORD_BOT_TOKEN) {
            logger.error('DISCORD_BOT_TOKEN .env dosyasında tanımlı değil!');
            return;
        }
        if (!process.env.CLIENT_ID) {
            logger.error('CLIENT_ID .env dosyasında tanımlı değil!');
            return;
        }
        if (!process.env.GUILD_ID) {
            logger.warn('GUILD_ID .env dosyasında tanımlı değil. Slash komutları global olarak kaydedilebilir, ancak geliştirme için önerilir.');
        }

        loadCommands();
        loadEvents();

        client.login(process.env.DISCORD_BOT_TOKEN).then(() => {
            registerSlashCommands();
            setupMesaiAutomation();
        }).catch(err => {
            logger.error('Discord botuna giriş yapılırken hata oluştu:', err);
        });
    },
    getClient: () => client,
    getUserData: getUserData, // Dışarıdan erişim için fonksiyonları export et
    addLogEntry: addLogEntry
};