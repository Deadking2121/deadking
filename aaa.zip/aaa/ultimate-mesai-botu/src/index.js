// src/index.js
require('dotenv').config(); // .env dosyasını en başta yükle

const logger = require('./core/logger');
// const connectDB = require('./database/connect'); // MongoDB bağlantısı kaldırıldı
const bot = require('./bot'); // Bot başlatma modülü
// const webApp = require('./web/app'); // Web uygulaması (daha sonra eklenecek)

// Veritabanı bağlantısı artık mongoose ile yapılmıyor.
// Quick.db kendi dosya sistemini kullanır.
logger.info('Veritabanı türü: Quick.db (dosya tabanlı). MongoDB bağlantısı gerekli değil.');


// Discord botunu başlat
bot.start();

// Web uygulamasını başlat (şimdilik yorum satırı, daha sonra eklenecek)
// const PORT = process.env.PORT || 3000;
// webApp.listen(PORT, () => {
//     logger.info(`Web sunucusu http://localhost:${PORT} adresinde çalışıyor.`);
// });

// Uygulama kapanırken temizlik
process.on('unhandledRejection', (reason, promise) => {
    logger.error('Yakalanmayan Reddedilme:', reason);
});

process.on('uncaughtException', (error) => {
    logger.error('Yakalanmayan Hata:', error);
    process.exit(1);
});