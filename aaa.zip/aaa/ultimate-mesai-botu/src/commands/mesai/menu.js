// src/commands/mesai/menu.js
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const User = require('../../database/models/User');
const { formatDuration } = require('../../core/utils');
const logger = require('../../core/logger');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mesaimenu')
        .setDescription('Mesai giriş/çıkış menüsünü gösterir.'),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: false }); // Herkesin görmesi için ephemeral: false

        const userId = interaction.user.id;
        const guildId = interaction.guild.id;

        let user = await User.findOne({ discordId: userId, guildId: guildId });
        let currentStatus = "Dışarıda";
        let currentMesaiDuration = "Yok";

        if (user && user.timesheets.length > 0 && !user.timesheets[user.timesheets.length - 1].endTime) {
            currentStatus = "Mesaide";
            const lastEntry = user.timesheets[user.timesheets.length - 1];
            const durationMs = new Date().getTime() - lastEntry.startTime.getTime();
            currentMesaiDuration = formatDuration(durationMs);
        }

        const embed = new EmbedBuilder()
            .setColor('Purple')
            .setTitle('Mesai Yönetim Menüsü')
            .setDescription(`Merhaba <@${userId}>! Mesai durumunuzu buradan yönetebilirsiniz.`)
            .addFields(
                { name: 'Mevcut Durum', value: `\`${currentStatus}\``, inline: true },
                { name: 'Mevcut Mesai Süresi', value: `\`${currentMesaiDuration}\``, inline: true }
            )
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('mesai_giris') // customId: mesai_komutAdi
                    .setLabel('Mesaiye Başla')
                    .setStyle(ButtonStyle.Success)
                    .setDisabled(currentStatus === "Mesaide"), // Zaten mesaideyse devre dışı bırak
                new ButtonBuilder()
                    .setCustomId('mesai_cikis')
                    .setLabel('Mesaiden Çık')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(currentStatus === "Dışarıda"), // Mesaide değilse devre dışı bırak
                new ButtonBuilder()
                    .setCustomId('mesai_yenile')
                    .setLabel('Durumu Yenile')
                    .setStyle(ButtonStyle.Primary)
            );

        await interaction.editReply({
            embeds: [embed],
            components: [row]
        });
    },
};