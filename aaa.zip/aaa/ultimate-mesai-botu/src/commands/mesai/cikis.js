// src/commands/mesai/cikis.js
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const User = require('../../database/models/User');
const Log = require('../../database/models/Log');
const logger = require('../../core/logger');
const { formatDuration } = require('../../core/utils');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('cikis')
        .setDescription('Mesaiden çıkış yapar.'),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });

        const userId = interaction.user.id;
        const username = interaction.user.username;
        const guildId = interaction.guild.id;

        try {
            let user = await User.findOne({ discordId: userId, guildId: guildId });

            if (!user || user.timesheets.length === 0 || user.timesheets[user.timesheets.length - 1].endTime) {
                const embed = new EmbedBuilder()
                    .setColor('Red')
                    .setTitle('Mesai Çıkış Hatası')
                    .setDescription('❌ Mesaide değilsiniz veya hiç mesai girişiniz yok.');
                return interaction.editReply({ embeds: [embed] });
            }

            const lastEntry = user.timesheets[user.timesheets.length - 1];
            lastEntry.endTime = new Date();
            lastEntry.duration = lastEntry.endTime.getTime() - lastEntry.startTime.getTime(); // Süreyi kaydet

            await user.save();

            const totalDuration = formatDuration(lastEntry.duration);

            const embed = new EmbedBuilder()
                .setColor('Blue')
                .setTitle('Mesai Çıkış Başarılı')
                .setDescription(`✅ Mesaiden çıktınız! Toplam mesai süreniz: **${totalDuration}**`);

            await interaction.editReply({ embeds: [embed] });

            // Log kaydı
            await Log.create({
                type: 'MESAI_CIKIS',
                userId: userId,
                username: username,
                guildId: guildId,
                details: `Mesaiden çıkış yaptı. Süre: ${totalDuration}`
            });

            logger.info(`${username} (${userId}) mesaiden çıkış yaptı.`);

            // Log kanalına bildirim
            const logChannel = client.channels.cache.get(process.env.LOG_CHANNEL_ID);
            if (logChannel) {
                logChannel.send(`🔴 **Mesai Çıkışı:** <@${userId}> mesaiden çıktı. Süre: ${totalDuration}`);
            }

        } catch (error) {
            logger.error(`Mesai çıkış hatası (${username}):`, error);
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('Hata')
                .setDescription('Mesaiden çıkış yaparken bir hata oluştu.');
            await interaction.editReply({ embeds: [embed] });
        }
    },
};