// src/commands/mesai/mesaim.js
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../database/models/User');
const logger = require('../../core/logger');
const { formatDuration } = require('../../core/utils');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mesaim')
        .setDescription('Kendi mesai bilgilerinizi gösterir.'),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });

        const userId = interaction.user.id;
        const guildId = interaction.guild.id;

        try {
            const user = await User.findOne({ discordId: userId, guildId: guildId });

            if (!user || user.timesheets.length === 0) {
                const embed = new EmbedBuilder()
                    .setColor('Orange')
                    .setTitle('Mesai Bilgisi')
                    .setDescription('⚠️ Hiç mesai kaydınız bulunmuyor.');
                return interaction.editReply({ embeds: [embed] });
            }

            let totalDurationMs = 0;
            let currentStatus = "Dışarıda";
            let currentMesaiStart = null;

            const lastEntry = user.timesheets[user.timesheets.length - 1];
            if (lastEntry && !lastEntry.endTime) {
                currentStatus = "Mesaide";
                currentMesaiStart = lastEntry.startTime;
                totalDurationMs += new Date().getTime() - lastEntry.startTime.getTime(); // Mevcut mesaiyi de hesapla
            }

            user.timesheets.forEach(entry => {
                if (entry.endTime) {
                    totalDurationMs += entry.duration; // Kaydedilmiş süreyi kullan
                }
            });

            const totalFormattedDuration = formatDuration(totalDurationMs);

            const embed = new EmbedBuilder()
                .setColor('Aqua')
                .setTitle(`${interaction.user.username} Mesai Bilgileri`)
                .addFields(
                    { name: 'Toplam Mesai Süresi', value: `\`${totalFormattedDuration}\``, inline: true },
                    { name: 'Şu Anki Durum', value: `\`${currentStatus}\``, inline: true }
                )
                .setTimestamp();

            if (currentMesaiStart) {
                embed.addFields({ name: 'Mevcut Mesai Başlangıcı', value: `<t:${Math.floor(currentMesaiStart.getTime() / 1000)}:F>`, inline: false });
            }

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            logger.error(`Mesai sorgulama hatası (${interaction.user.username}):`, error);
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('Hata')
                .setDescription('Mesai bilgilerinizi alırken bir hata oluştu.');
            await interaction.editReply({ embeds: [embed] });
        }
    },
};