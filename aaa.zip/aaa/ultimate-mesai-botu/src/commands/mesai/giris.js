// src/commands/mesai/giris.js
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const User = require('../../database/models/User');
const Log = require('../../database/models/Log');
const logger = require('../../core/logger');
const { formatDuration } = require('../../core/utils');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giris')
        .setDescription('Mesaiye giriş yapar.'),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true }); // Yanıtı geciktir

        const userId = interaction.user.id;
        const username = interaction.user.username;
        const guildId = interaction.guild.id;

        try {
            let user = await User.findOne({ discordId: userId, guildId: guildId });

            if (!user) {
                user = new User({
                    discordId: userId,
                    username: username,
                    guildId: guildId,
                    timesheets: [],
                });
            }

            if (user.timesheets.length > 0 && !user.timesheets[user.timesheets.length - 1].endTime) {
                const lastEntry = user.timesheets[user.timesheets.length - 1];
                const currentDurationMs = new Date().getTime() - lastEntry.startTime.getTime();
                const currentDuration = formatDuration(currentDurationMs);

                const embed = new EmbedBuilder()
                    .setColor('Red')
                    .setTitle('Mesai Giriş Hatası')
                    .setDescription(`❌ Zaten mesaide görünüyorsunuz! Mevcut mesai süreniz: **${currentDuration}**`)
                    .setTimestamp();

                return interaction.editReply({ embeds: [embed] });
            }

            user.timesheets.push({ startTime: new Date() });
            await user.save();

            const embed = new EmbedBuilder()
                .setColor('Green')
                .setTitle('Mesai Giriş Başarılı')
                .setDescription(`✅ Mesaiye başladınız! İyi çalışmalar, <@${userId}>.`);

            await interaction.editReply({ embeds: [embed] });

            // Log kaydı
            await Log.create({
                type: 'MESAI_GIRIS',
                userId: userId,
                username: username,
                guildId: guildId,
                details: `Mesaiye giriş yaptı.`
            });

            logger.info(`${username} (${userId}) mesaiye giriş yaptı.`);

            // Log kanalına bildirim
            const logChannel = client.channels.cache.get(process.env.LOG_CHANNEL_ID);
            if (logChannel) {
                logChannel.send(`🟢 **Mesai Girişi:** <@${userId}> mesaiye başladı.`);
            }

        } catch (error) {
            logger.error(`Mesai giriş hatası (${username}):`, error);
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('Hata')
                .setDescription('Mesaiye giriş yaparken bir hata oluştu.');
            await interaction.editReply({ embeds: [embed] });
        }
    },
};