// src/commands/admin/checkrank.js
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../database/models/User');
const logger = require('../../core/logger');
const config = require('../../../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('checkrank')
        .setDescription('Bir kullanıcının mevcut rütbesini kontrol eder.')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('Rütbesi kontrol edilecek kullanıcı.')
                .setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });

        const member = interaction.guild.members.cache.get(interaction.user.id);
        const highCommandRole = config.ranks.find(r => r.id === 'rank_id_high_command')?.roleId;
        if (!member.roles.cache.has(highCommandRole)) {
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('Yetkisiz Erişim')
                .setDescription('❌ Bu komutu kullanmak için yeterli yetkiniz yok.');
            return interaction.editReply({ embeds: [embed] });
        }

        const targetUser = interaction.options.getUser('target');
        const guildId = interaction.guild.id;

        try {
            const userDoc = await User.findOne({ discordId: targetUser.id, guildId: guildId });

            if (!userDoc) {
                const embed = new EmbedBuilder()
                    .setColor('Orange')
                    .setTitle('Rütbe Bilgisi')
                    .setDescription(`⚠️ <@${targetUser.id}> kullanıcısının veritabanında bir kaydı bulunmuyor. Varsayılan rütbesi: **Üye**`);
                return interaction.editReply({ embeds: [embed] });
            }

            const embed = new EmbedBuilder()
                .setColor('Blue')
                .setTitle('Rütbe Bilgisi')
                .setDescription(`<@${targetUser.id}> kullanıcısının mevcut rütbesi: **${userDoc.rank}**`);

            await interaction.editReply({ embeds: [embed] });

            logger.info(`${interaction.user.username} (${interaction.user.id}) kullanıcısının rütbesini kontrol etti: ${targetUser.username} (${targetUser.id}) - ${userDoc.rank}`);

        } catch (error) {
            logger.error(`Rütbe kontrol hatası (${interaction.user.username}):`, error);
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('Hata')
                .setDescription('Rütbe bilgisi alınırken bir hata oluştu.');
            await interaction.editReply({ embeds: [embed] });
        }
    },
};