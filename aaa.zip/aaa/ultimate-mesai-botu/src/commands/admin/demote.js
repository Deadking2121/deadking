// src/commands/admin/demote.js
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../database/models/User');
const Log = require('../../database/models/Log');
const logger = require('../../core/logger');
const config = require('../../../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('demote')
        .setDescription('Bir kullanıcının rütbesini düşürür.')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('Rütbesi düşürülecek kullanıcı.')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('rank')
                .setDescription('Atanacak yeni (düşük) rütbe.')
                .setRequired(true)
                .addChoices(
                    ...config.ranks.map(r => ({ name: r.name, value: r.name }))
                )),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });

        const member = interaction.guild.members.cache.get(interaction.user.id);
        const highCommandRole = config.ranks.find(r => r.id === 'rank_id_high_command')?.roleId;
        if (!member.roles.cache.has(highCommandRole)) {
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('Yetkisiz Erişim')
                .setDescription('❌ Bu komutu kullanmak için yeterli yetkiniz yok.');
            return interaction.editReply({ embeds: [embed] });
        }

        const targetUser = interaction.options.getUser('target');
        const newRankName = interaction.options.getString('rank');
        const guildId = interaction.guild.id;

        const newRankConfig = config.ranks.find(r => r.name === newRankName);
        if (!newRankConfig) {
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('Hata')
                .setDescription('Belirtilen rütbe bulunamadı.');
            return interaction.editReply({ embeds: [embed] });
        }

        try {
            let userDoc = await User.findOne({ discordId: targetUser.id, guildId: guildId });

            if (!userDoc) {
                const embed = new EmbedBuilder()
                    .setColor('Red')
                    .setTitle('Hata')
                    .setDescription('Kullanıcı veritabanında bulunamadı.');
                return interaction.editReply({ embeds: [embed] });
            }

            const oldRank = userDoc.rank;
            userDoc.rank = newRankName;
            await userDoc.save();

            // Discord rolünü güncelle
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            if (targetMember) {
                for (const rank of config.ranks) {
                    if (targetMember.roles.cache.has(rank.roleId)) {
                        await targetMember.roles.remove(rank.roleId).catch(err => logger.error(`Rol kaldırılamadı: ${err.message}`));
                    }
                }
                await targetMember.roles.add(newRankConfig.roleId).catch(err => logger.error(`Rol eklenemedi: ${err.message}`));
            }

            const embed = new EmbedBuilder()
                .setColor('Orange')
                .setTitle('Rütbe Düşürüldü')
                .setDescription(`⬇️ <@${targetUser.id}> kullanıcısının rütbesi başarıyla **${newRankName}** olarak düşürüldü.`);

            await interaction.editReply({ embeds: [embed] });

            // Log kaydı
            await Log.create({
                type: 'RUTBE_DUSURME',
                userId: targetUser.id,
                username: targetUser.username,
                guildId: guildId,
                details: `${interaction.user.username} tarafından ${oldRank} rütbesinden ${newRankName} rütbesine düşürüldü.`,
                performerId: interaction.user.id,
                performerUsername: interaction.user.username
            });

            logger.info(`${interaction.user.username} (${interaction.user.id}) kullanıcısını ${targetUser.username} (${targetUser.id}) adlı kişinin rütbesini ${newRankName} olarak düşürdü.`);

            // Log kanalına bildirim
            const logChannel = client.channels.cache.get(process.env.LOG_CHANNEL_ID);
            if (logChannel) {
                logChannel.send(`⬇️ **Rütbe Düşürme:** <@${interaction.user.id}>, <@${targetUser.id}> kullanıcısının rütbesini **${newRankName}** olarak düşürdü.`);
            }

        } catch (error) {
            logger.error(`Rütbe düşürme hatası (${interaction.user.username}):`, error);
            const embed = new EmbedBuilder()
                .setColor('Red')
                .setTitle('Hata')
                .setDescription('Rütbe düşürülürken bir hata oluştu.');
            await interaction.editReply({ embeds: [embed] });
        }
    },
};