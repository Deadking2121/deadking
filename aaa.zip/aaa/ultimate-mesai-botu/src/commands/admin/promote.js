// src/commands/admin/promote.js
const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../../../config'); // config.js dosyasını dahil et

module.exports = {
    data: new SlashCommandBuilder()
        .setName('promote')
        .setDescription('Bir kullanıcının rütbesini yükseltir.')
        .addUserOption(option =>
            option.setName('target')
                .setDescription('Rütbesi yükseltilecek kullanıcı.')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('new_rank')
                .setDescription('Yeni rütbe.')
                .setRequired(true)),
    // .setDefaultMemberPermissions(PermissionFlagsBits.Administrator) // Bu komutu sadece belirli rollere atayacaksanız, Discord panelinden ayarlamak daha esnek olabilir.
                                                                     // Veya config.js'den yönetici rütbelerini kontrol edebilirsiniz.

    async execute(interaction, client) {
        const db = client.db; // Quick.db erişimi
        const targetUser = interaction.options.getUser('target');
        const newRankName = interaction.options.getString('new_rank');
        const guildId = interaction.guildId;
        const executorId = interaction.user.id;
        const executorUsername = interaction.user.username;

        // 1. Komutun bir sunucuda kullanılıp kullanılmadığını kontrol et
        if (!interaction.inGuild()) {
            return interaction.reply({ content: 'Bu komut sadece sunucularda kullanılabilir.', ephemeral: true });
        }

        // 2. Yükseltme yapacak kişinin yetkisini kontrol et
        // Buradaki yetki kontrolü config.js'deki rütbe seviyelerine göre yapılabilir.
        // Şimdilik sadece Admin yetkisine sahip kişilerin kullanabildiğini varsayalım.
        // Daha gelişmiş bir rütbe sistemi için 'checkrank' veya benzeri bir yetki kontrol fonksiyonu eklenebilir.
        const executorUserData = await client.getUserData(executorId, guildId, executorUsername);
        const executorRankLevel = config.ranks[executorUserData.rank]?.level || 0;
        
        // Komutu kullanana kişi en az 3. seviye (örneğin Süpervizör veya Admin) olmalı
        const requiredLevelForPromote = 3; // config.js'den alınabilir
        if (executorRankLevel < requiredLevelForPromote) {
            return interaction.reply({ content: `Bu komutu kullanmak için yetkiniz yeterli değil. Gerekli rütbe seviyesi: ${requiredLevelForPromote}`, ephemeral: true });
        }


        // 3. Hedef kullanıcının sunucuda üye olduğundan emin ol ve verilerini çek
        // Hata aldığınız yer burasıydı. interaction.guild.members.fetch() kullanarak hedef kullanıcının sunucu üyesi objesini almalıyız.
        const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(error => {
            logger.error(`Promote komutunda hedef üye çekilemedi: ${error.message}`);
            return null;
        });

        if (!targetMember) {
            return interaction.reply({ content: 'Belirtilen kullanıcı bu sunucuda bulunmuyor.', ephemeral: true });
        }

        // Hedef kullanıcının güncel Quick.db verilerini al veya oluştur
        let targetUserData = await client.getUserData(targetUser.id, guildId, targetUser.username);

        // Yeni rütbenin config.js'de tanımlı olup olmadığını kontrol et
        const newRankConfig = config.ranks[newRankName];
        if (!newRankConfig) {
            return interaction.reply({ content: `"${newRankName}" adında bir rütbe bulunamadı. Lütfen config.js dosyanızdaki rütbelerden birini girin.`, ephemeral: true });
        }

        // Rütbe seviyesi kontrolü: Yükseltme yapan kişi, yükselttiği kişiden daha yüksek rütbe olmalı
        const targetRankLevel = config.ranks[targetUserData.rank]?.level || 0;
        if (executorRankLevel <= newRankConfig.level && executorId !== interaction.guild.ownerId) { // Sunucu sahibi kendini veya başkasını yükseltebilir
            return interaction.reply({ content: `Kendi rütbenize eşit veya daha yüksek bir rütbeyi atayamazsınız (veya sunucu sahibi değilsiniz).`, ephemeral: true });
        }

        if (newRankConfig.level <= targetRankLevel) {
             return interaction.reply({ content: `Kullanıcının rütbesi zaten "${newRankName}" veya daha yüksek.`, ephemeral: true });
        }

        // Rütbeyi güncelle
        const oldRank = targetUserData.rank;
        targetUserData.rank = newRankName;
        await db.set(`users.${targetUser.id}`, targetUserData); // Quick.db'de güncelle

        // Log kaydı oluştur
        await client.addLogEntry(
            'RANK_PROMOTED',
            targetUser.id,
            targetUser.username,
            guildId,
            `Rütbesi "${oldRank}" iken "${newRankName}" olarak yükseltildi.`,
            executorId,
            executorUsername
        );

        await interaction.reply({ content: `<@${targetUser.id}> kullanıcısının rütbesi başarıyla **${newRankName}** olarak ayarlandı.`, ephemeral: false });

        // Log kanalına da bildirim gönder
        const logChannelId = process.env.LOG_CHANNEL_ID;
        if (logChannelId) {
            const logChannel = interaction.client.channels.cache.get(logChannelId);
            if (logChannel) {
                logChannel.send(`⬆️ **Rütbe Yükseltme:** <@${targetUser.id}> kullanıcısının rütbesi <@${executorId}> tarafından **${newRankName}** olarak yükseltildi.`);
            }
        }
    },
};