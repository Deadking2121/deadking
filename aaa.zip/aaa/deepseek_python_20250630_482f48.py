import os
from pathlib import Path

structure = {
    ".env": None,
    "config.js": None,
    "package.json": None,
    "package-lock.json": None,
    "src": {
        "index.js": None,
        "bot": {
            "index.js": None
        },
        "commands": {
            "admin": {
                "checkrank.js": None,
                "demote.js": None,
                "promote.js": None
            },
            "mesai": {
                "cikis.js": None,
                "giris.js": None,
                "mesaim.js": None,
                "menu.js": None
            },
            "ping.js": None
        },
        "core": {
            "logger.js": None,
            "utils.js": None
        },
        "database": {
            "connect.js": None,
            "models": {
                "Log.js": None,
                "User.js": None
            }
        },
        "events": {
            "interactionCreate.js": None,
            "ready.js": None
        }
    },
    "logs": {
        "combined.log": None,
        "error.log": None
    }
}

def create_structure(base_path, structure):
    for name, content in structure.items():
        path = base_path / name
        if content is None:
            # Dosya oluştur
            path.touch()
            print(f"Created file: {path}")
        else:
            # Klasör oluştur ve içine gir
            path.mkdir(exist_ok=True)
            print(f"Created directory: {path}")
            create_structure(path, content)

if __name__ == "__main__":
    base_dir = Path("ultimate-mesai-botu")
    if not base_dir.exists():
        base_dir.mkdir()
        print(f"Main directory created: {base_dir}")
    else:
        print(f"Directory already exists: {base_dir}")
    
    create_structure(base_dir, structure)
    print("Folder structure created successfully!")